<?php

$dbconnect= mysqli_connect('localhost','root','','kaiwa_internal');
$query= "insert into questions_table (Questions) values (1)";
$query1="select last_insert_id();";
$result=mysqli_query($dbconnect,$query);
$result1=mysqli_query($dbconnect,$query1);

$ques= $result1->fetch_array();
$ques_id = $ques[0];
echo $ques_id;

?>