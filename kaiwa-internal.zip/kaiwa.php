<html>

<head>
 <meta charset="UTF-8">
 <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
 <!--<meta http-equiv="X-UA-Compatible" content="ie=edge">-->


 <style>
  @media (max-width:556px) {
      content{
          margin-top:30%;
      }
   h2{ font-size: 20px;
   top:30%;
      }
  

  p {
   font-size: 12px;
  }
  }

 </style>


</head>

<?php
    $question='';
    $surveycode='';
    $project_id='';
    if(isset($_POST['question_list'])){
      $question= $_POST['question_list'];
    }
		if(isset($_POST['project_id'])){
			$project_id = $_POST['project_id'];
		}
        if(isset($_POST['survey1'])){
			$surveycode = $_POST['survey1'];
		}
    
    $questions_arr = explode(",",$question);
$dbconnect=mysqli_connect('localhost','root','','kaiwa_internal');
    $n = count($questions_arr);
    $a=$n;
    foreach($_POST['array'] as $element){
        
        $question_id = $questions_arr[$a-$n];

        $a++;

         $sql="INSERT INTO response_table(Survey_link, Questions, Answers, Project_id) VALUES ('$surveycode','$question_id','$element','$project_id')";
 $run=mysqli_query($dbconnect,$sql);
    }
    
    

 
 if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    //you need to exit the script, if there is an error
    exit();
} 

 ?>

<body style="overflow:hidden;">
 <div style="margin-top:15%; padding:5px;">

  <!--<img src="./Presentation1.jpg" alt="thankyou" height="auto" width="80%"  max-width="80%">-->
<center>
  <h2 style="color:#339fd9; text-align:center; font-size:20px;">"We really appreciate all the hard work you are putting in and we will get through this together.<br>Take good care of yourself. Thank you!"<br>
 <br><br> If you would like to discuss anything related to this survey please contact,<br> matthew.henderson@bradford.gov.uk<br>www.bradfordforeveryone.co.uk</h2>
</center>
  
 </div>
</body>

</html>
