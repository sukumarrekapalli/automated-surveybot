<html>

<head>
 <meta charset="UTF-8">
 <!--<meta name="viewport" content="width=device-width, initial-scale=1.0">-->
 <!--<meta http-equiv="X-UA-Compatible" content="ie=edge">-->


 <style>
  @media (max-width:556px) {
      content{
          margin-top:30%;
      }
   h2{ font-size: 20px;
   top:30%;
      }
  

  p {
   font-size: 12px;
  }
  }

 </style>


</head>

<?php

$industry='';
$industry1='';
$ethnicity='';
$faith='';
$faith1='';
$gender='';
$gender1='';
$cob='';
$uk='';
$bradford='';
$age='';
$q1='';
$q2='';
 $q3='';
 $q4='';
 $q5='';
 $q6='';
 $q7='';
 $q8='';
 $q9='';
 $q10='';
 $q11='';
 $q12='';
 $q13='';
 $q15='';
 $efforts='';
 $challenge='';
 $q18='';
 $q19='';
 $feel='';
 $improvement='';
 


 
if(isset($_POST['industry']))
{
$industry = $_POST['industry'];
}
if(isset($_POST['industry1']))
{
$industry1 = $_POST['industry1'];
}
if(isset($_POST['ethnicity']))
{
$ethnicity = $_POST['ethnicity'];
}
if(isset($_POST['faith']))
{
$faith = $_POST['faith'];
}
if(isset($_POST['faith1']))
{
$faith1 = $_POST['faith1'];
}
if(isset($_POST['gender']))
{
$gender = $_POST['gender'];
}
if(isset($_POST['gender1']))
{
$gender1 = $_POST['gender1'];
}
if(isset($_POST['cob']))
{
$cob = $_POST['cob'];
}
if(isset($_POST['uk']))
{
$uk = $_POST['uk'];
}
if(isset($_POST['bradford']))
{
$bradford = $_POST['bradford'];
}
if(isset($_POST['age']))
{
$age = $_POST['age'];
}
 if(isset($_POST['q1']))
{
$q1 = $_POST['q1'];
}
 if(isset($_POST['q2']))
{
$q2 = $_POST['q2'];
}
 if(isset($_POST['q3']))
{
$q3 = $_POST['q3'];
}
 if(isset($_POST['q4']))
{
$q4 = $_POST['q4'];
}
 if(isset($_POST['q5']))
{
$q5 = $_POST['q5'];
}
 if(isset($_POST['q6']))
{
$q6 = $_POST['q6'];
}
 if(isset($_POST['q7']))
{
$q7 = $_POST['q7'];
}
 if(isset($_POST['q8']))
{
$q8 = $_POST['q8'];
}
 if(isset($_POST['q9']))
{
$q9 = $_POST['q9'];
}
 if(isset($_POST['q10']))
{
$q10 = $_POST['q10'];
}
 if(isset($_POST['q11']))
{
$q11 = $_POST['q11'];
}
 if(isset($_POST['q12']))
{
$q12 = $_POST['q12'];
}
 if(isset($_POST['q13']))
{
$q13 = $_POST['q13'];
}
 if(isset($_POST['q15']))
{
$q15 = $_POST['q15'];
}
 if(isset($_POST['efforts']))
{
$efforts = $_POST['efforts'];
}
 if(isset($_POST['challenge']))
{
$challenge = $_POST['challenge'];
}
 if(isset($_POST['q18']))
{
$q18 = $_POST['q18'];
    $q18check="";  
    foreach($q18 as $q18check1)  
       {  
          $q18check.= $q18check1.",";  
       } 
}
 if(isset($_POST['q19']))
{
$q19 = $_POST['q19'];
}
 if(isset($_POST['improvement']))
{
$improvement = $_POST['improvement'];
}

if(isset($_POST['feel']))
{
$feel = $_POST['feel'];
}

date_default_timezone_set("Asia/Kolkata");

$date = date("Y-m-d H:i:s");
 
$dbconnect=mysqli_connect('localhost','udaydb','Transce123','culturelytics_db');
                                                                                                                                                                                       

 $sql="insert into bradfordkaiwatable (Time_stamp,industry,industry1,ethnicity,faith,faith1,gender,gender1,cob,uk,bradford,age,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q15,efforts,challenge,q18,q19,feel,improvement) values  ('$date','$industry','$industry1','$ethnicity','$faith','$faith1','$gender','$gender1','$cob','$uk','$bradford','$age','$q1','$q2','$q3','$q4','$q5','$q6','$q7','$q8','$q9','$q10','$q11','$q12','$q13','$q15','$efforts','$challenge','$q18check','$q19','$feel','$improvement')";
 $run=mysqli_query($dbconnect,$sql);
 
 
 if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    //you need to exit the script, if there is an error
    exit();
} 

 ?>

<body style="overflow:hidden;">
 <div style="margin-top:15%; padding:5px;">

  <!--<img src="./Presentation1.jpg" alt="thankyou" height="auto" width="80%"  max-width="80%">-->
<center>
  <h2 style="color:#339fd9; text-align:center; font-size:20px;">"We really appreciate all the hard work you are putting in and we will get through this together.<br>Take good care of yourself. Thank you!"<br>
 <br><br> If you would like to discuss anything related to this survey please contact,<br> matthew.henderson@bradford.gov.uk<br>www.bradfordforeveryone.co.uk</h2>
</center>
  
 </div>
</body>

</html>
